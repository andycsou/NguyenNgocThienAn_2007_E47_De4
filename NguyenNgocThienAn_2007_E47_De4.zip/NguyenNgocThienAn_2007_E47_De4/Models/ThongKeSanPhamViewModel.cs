﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NguyenNgocThienAn_2007_E47_De4.Models
{
    public class ThongKeSanPhamViewModel
    {
        public string MaKhachHang { get; set; }
        public string TenCongTy { get; set; }
        public int TongSanPham { get; set; }
    }

}